from Operacoes import somar
from Operacoes import dividir
from Operacoes import subtrair
from Operacoes import multiplicar
from Operacoes import raiz

def main():
    print("Escolha como deseja fazer as operações que quer efetuar:")
    opt = int(input("1-Todas as operações\n2-Escolher operação\nOpção - "))
    match opt:
        case 1:
            print("Introduza dois valores:")
            x:float = float(input("x="))
            y:float = float(input("y="))
            
            s:object = somar.Somar()
            res = s.executar(x,y)
            print("O valor da operação somar é:", res)
            
            s:object = subtrair.Subtrair()
            res = s.executar(x,y)
            print("O valor da operação subtrair é:", res)
            
            s:object = multiplicar.Multiplicar()
            res = s.executar(x,y)
            print("O valor da operação multiplicar é:", res)
            
            s:object = dividir.Dividir()
            res = s.executar(x,y)
            if isinstance(res, ZeroDivisionError):
                print("Erro: divisão por zero")
            else:
                print("O valor da operação divisão é:",res)
                
            s:object = raiz.Raiz()
            result = s.executar(x)
            if isinstance(result, ValueError):
                print("Erro: não é possível calcular a raiz quadrada de um número negativo.")
            else:                
                print("O valor da operação raiz quadrada do 1º valor é:", result)   
                 
        case 2:
            print("Qual é o cálculo que quer efetuar? x, +, -, /, *")
            res:str = input()
            if res == "*":
                print("Introduza o valor que quer descobrir a raiz quadrada:")
                x:float = float(input("x="))
                s:object = raiz.Raiz()
                result = s.executar(x)
                if isinstance(result, ValueError):
                    print("Erro: não é possível calcular a raiz quadrada de um número negativo.")
                else:
                    print("O valor da operação raiz quadrada é:", result)
                    
            else:
                print("Introduza dois valores:")
                x:float = float(input("x="))
                y:float = float(input("y="))
                
                if res =="+":
                    s:object = somar.Somar()
                    res = s.executar(x,y)
                    print("O valor da operação somar é:", res)
                    
                elif res == "-":
                    s:object = subtrair.Subtrair()
                    res = s.executar(x,y)
                    print("O valor da operação subtrair é:", res)
                    
                elif res == "x":
                    s:object = multiplicar.Multiplicar()
                    res = s.executar(x,y)
                    print("O valor da operação multiplicar é:", res)
                    
                elif res =="/":
                    s:object = dividir.Dividir()
                    res = s.executar(x,y)
                    if isinstance(res, ZeroDivisionError):
                        print("Erro: divisão por zero")
                    else:
                        print("O valor da operação divisão é:",res)

if __name__ == '__main__':
    main()
