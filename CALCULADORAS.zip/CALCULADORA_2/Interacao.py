from Operacoes.somar import Somar as s
from Operacoes.dividir import Dividir as d
from Operacoes.subtrair import Subtrair as sub
from Operacoes.multiplicar import Multiplicar as m
from Operacoes.raiz import Raiz as r

class Interacao:
    """
    Classe que permite a interação entre a execução 
    do programa e as operações
    """

    def execute(self):
        """
        Método execute.
        Este método permite a criação de instâncias das várias operações
        apresentando o resultado de cada um conforme os valores colocados pelo utilizador

        Raises:
            ZeroDivisionError: Caso "y" seja 0 (divisão por 0)
            ValueError: Caso "x" seja < 0 (raiz de nº negativo)
        """
        print("Preciso que introduza dois valores:")
        x: float = float(input("x="))
        y: float = float(input("y="))

        mult: object = m()
        div: object = d()
        soma: object = s()
        raiz: object = r()
        subtracao: object = sub()

        z: float = mult.executar(x, y)
        print("O resultado da multiplicação é:", z)


        z = div.executar(x, y)
        if z == ZeroDivisionError():
            raise ZeroDivisionError("Erro: divisão por zero")
        else:
            print("O resultado da divisão é:", z)

        f: float = soma.executar(x, y)
        print("O resultado da soma é:", f)

        l: float = raiz.executar(x)
        if l == ValueError():
            raise ValueError("Erro: não é possível calcular a raiz quadrada de um número negativo")
        else:
            print("O resultado da raiz quadrada é:", l)

        n: float = subtracao.executar(x, y)
        print("O resultado da subtração é:", n)
