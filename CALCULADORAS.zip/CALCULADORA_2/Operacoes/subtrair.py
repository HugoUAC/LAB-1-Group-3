class Subtrair:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.res = 0


    def executar(self,x,y)->float:
        """
        Faz a subtração de dois números.
        :param x: 1º valor
        :param y: 2º valor
        :return: retorna o resultado da subtração
        """
        self.x = x
        self.y = y
        self.res = self.x - self.y
        return self.res