from typing import Union

class Dividir:
    
    def __init__(self):
        self.x = 0
        self.y = 0
        self.res = 0


    def executar(self,x,y)-> Union[float, ZeroDivisionError]:
        """
        Divide dois números
        :param x: valor a dividir
        :param y: valor a dividir por
        :return: retorna o resultado da divisão ou uma mensagem de erro se y for zero
        """
        try:
            self.x = x
            self.y = y
            self.res = self.x / self.y
        except ZeroDivisionError:
            return ZeroDivisionError()
        return self.res
