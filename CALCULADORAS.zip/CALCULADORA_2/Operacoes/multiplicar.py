class Multiplicar:

    def __init__(self):
        self.x = 0
        self.y = 0
        self.res = 0


    def executar(self,x,y)->float:
        """
        Multiplica dois números
        :param x: valor a multiplicar
        :param y: valor a multiplicar por
        :return: retorna o resultado da multiplicação
        """
        self.x = x
        self.y = y
        self.res = self.x * self.y
        return self.res
