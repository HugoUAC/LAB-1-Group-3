from typing import Union
import math

class Raiz:
    def __init__(self):
        self.x = 0
        self.res = 0


    def executar(self, x: float) -> Union[float, ValueError]:
        """
        Calcula a raiz quadrada de um número
        :param x: valor a calcular a raiz quadrada
        :return: retorna o resultado da raiz quadrada ou uma exceção ValueError se x for negativo
        """

        self.x = x
        try:
            self.res = math.sqrt(self.x)
        except ValueError:
            return ValueError()
        return self.res
