class Somar:
    
    def __init__(self):
        self.x = 0
        self.y = 0
        self.res = 0


    def executar(self,x,y)->float:
        """
        Soma dois números
        :param x: valor a somar
        :param y: valor a somar por
        :return: retorna o resultado da soma
        """
    
        self.x = x
        self.y = y
        self.res = self.x + self.y
        return self.res