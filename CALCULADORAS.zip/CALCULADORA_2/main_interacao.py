import Interacao

if __name__ == "__main__":
    interacao = Interacao.Interacao()
    interacao.execute()