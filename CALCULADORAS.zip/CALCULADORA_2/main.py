from Operacoes import somar
from Operacoes import dividir
from Operacoes import subtrair
from Operacoes import multiplicar
from Operacoes import raiz

def main():
    print("Qual é o cálculo que quer efetuar? x, +, -, /, *")
    res:str = input()
    if res == "*":
        print("Introduza o valor que quer descobrir a raiz quadrada:")
        x:float = float(input("x="))
        s:object = raiz.Raiz()
        result = s.executar(x)
        if isinstance(result, ValueError):
            print("Erro: não é possível calcular a raiz quadrada de um número negativo.")
        else:
            print("O valor da operação raiz quadrada é:", result)
            
    else:
        print("Introduza dois valores:")
        x:float = float(input("x="))
        y:float = float(input("y="))
        
        if res =="+":
            s:object = somar.Somar()
            res = s.executar(x,y)
            print("O valor da operação somar é:", res)
            
        elif res == "-":
            s:object = subtrair.Subtrair()
            res = s.executar(x,y)
            print("O valor da operação subtrair é:", res)
            
        elif res == "x":
            s:object = multiplicar.Multiplicar()
            res = s.executar(x,y)
            print("O valor da operação multiplicar é:", res)
            
        elif res =="/":
            s:object = dividir.Dividir()
            res = s.executar(x,y)
            if type(res)==str:
                print(res)
            else:
                print("O valor da operação divisão é:",res)

if __name__ == '__main__':
    main()
