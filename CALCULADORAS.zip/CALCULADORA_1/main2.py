import dividir as d
import somar as s
import subtrair as sub
import multiplicar as m
import raiz as r

def main():
    """Função principal do programa, onde é feita a interação com o utilizador
    """
    print("Introduza dois valores:")
    x:float = float(input("x="))
    y:float = float(input("y="))

    print("O valor da operação somar é:", s.somar(x,y))

    print("O valor da operação subtrair é:", sub.subtrair(x,y))

    print("O valor da operação multiplicar é:", m.multiplicar(x,y))

    if y == 0:
        print("Erro: divisão por zero")
    else:
        print("O valor da operação divisão é:", d.dividir(x,y))

    if x < 0:
        print("Erro: não é possível calcular a raiz quadrada de um número negativo.")
    else:
        print("O valor da operação raiz quadrada do 1º valor é:", r.raizquadrada(x,))


if __name__ == '__main__':
    main()
