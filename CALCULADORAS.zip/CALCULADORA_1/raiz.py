def raizquadrada( x: float) -> float:
    if x < 0:
        raise ValueError("Não é possível calcular a raiz quadrada de um número negativo.")
    return x ** 0.5