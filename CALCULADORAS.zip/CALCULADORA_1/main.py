def subtrair(x: float, y: float) -> float:
    """
    Subtrai dois números
    :param x: valor subtraido
    :param y: valor a subtrair
    :return: retorna o resultado da subtraçao
    """
    return x - y


def somar(x: float, y: float) -> float:
    """
    Soma dois números
    :param x: valor a somar
    :param y: valor a somar
    :return: retorna o resultado da soma
    """
    return x + y


def dividir(x: float, y: float) -> float:
    """"
    Divide dois números
    :param x: valor dividendo
    :param y: valor divisor
    :return: retorna o resultado da divisão
    """
    if y == 0:
        raise ZeroDivisionError("Cannot divide by zero")
    return x / y


def multiplicar(x: float, y: float) -> float:
    """""
    Multiplica dois números
    :param x: valor a multiplicar
    :param y: valor a multiplicar
    :return: retorna o resultado da multiplicação
    """
    return x * y

def raizquadrada( x: float) -> float:
    """
    Calcula a raiz quadrada de um número
    :param x: valor a calcular a raiz quadrada
    :return: retorna o resultado da raiz quadrada"""
    if x < 0:
        raise ValueError("Não é possível calcular a raiz quadrada de um número negativo.")
    return x ** 0.5

def main():
    """Função principal do programa, onde é feita a interação com o utilizador
    """
    print("Qual é o cálculo que quer efetuar? x, +, -, /, * (raizquadrada)")
    res: str = input()
    if res == "*":
        print("Preciso que introduza o valor:")
        x: float = float(input("x="))
    else:
        print("Preciso que introduza dois valores:")
        x: float = float(input("x="))
        y: float = float(input("y="))

    # Teste
    # print(res)
    if res == "x":
        z: float = multiplicar(x, y)
        print("O resultado da multiplicação é:", z)

    elif res == "/":
        try:
            z = dividir(x,y)
            print("O resultado da divisão é:", z)
        except ZeroDivisionError as e:
            print("Error:", e)

    elif res == "+":
        m: float = somar(x, y)
        print("O resultado da soma é:", m)

    elif res == "*":
        try:
            r: float = raizquadrada(x)
            print("O resultado da raiz quadrada é:", r)
        except ValueError as e:
            print("Error:", e)

    else:
        n: float = subtrair(x, y)
        print("O resultado da subtração é:", n)


if __name__ == '__main__':
    main()
